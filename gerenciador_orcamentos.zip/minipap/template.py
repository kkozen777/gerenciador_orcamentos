import tkinter as tk
from tkinter import ttk
import mysql.connector

class CategoriesManager:
    def __init__(self, master, db_host, db_user, db_password, db_name, table_name):
        self.master = master
        self.table_name = table_name

        # Conectar ao banco de dados MySQL
        self.db = mysql.connector.connect(
            host=db_host,
            user=db_user,
            password=db_password,
            database=db_name
        )
        self.cursor = self.db.cursor()

        # Criar a Treeview
        self.trv_categories = ttk.Treeview(self.master, columns=("id", "name", "description"), show='headings')
        self.trv_categories.heading("id", text="ID")
        self.trv_categories.heading("name", text="Nome")
        self.trv_categories.heading("description", text="Descrição")
        self.trv_categories.column("id", width=50)
        self.trv_categories.column("name", width=150)
        self.trv_categories.column("description", width=200)
        self.trv_categories.grid(row=0, column=0, padx=10, pady=10, sticky="NSEW")

        # Adicionar botões
        self.btn_add = tk.Button(self.master, text="Adicionar", command=self.add_category)
        self.btn_edit = tk.Button(self.master, text="Editar", command=self.edit_category)
        self.btn_delete = tk.Button(self.master, text="Excluir", command=self.delete_category)
        self.btn_add.grid(row=1, column=0, padx=10, pady=10, sticky="W")
        self.btn_edit.grid(row=1, column=1, padx=10, pady=10, sticky="W")
        self.btn_delete.grid(row=1, column=2, padx=10, pady=10, sticky="E")

        # Carregar os dados da tabela "categorias"
        self.load_categories()

    def load_categories(self):
        # Limpar a Treeview
        for item in self.trv_categories.get_children():
            self.trv_categories.delete(item)

        # Carregar os dados da tabela "categorias"
        self.cursor.execute(f"SELECT id, name, description FROM {self.table_name}")
        categories = self.cursor.fetchall()
        for category in categories:
            self.trv_categories.insert("", tk.END, values=category)

    def add_category(self):
        # Criar uma nova janela para adicionar uma categoria
        add_window = tk.Toplevel(self.master)
        add_window.title("Adicionar Categoria")

        name_label = tk.Label(add_window, text="Nome:")
        name_entry = tk.Entry(add_window)
        description_label = tk.Label(add_window, text="Descrição:")
        description_entry = tk.Entry(add_window)
        save_button = tk.Button(add_window, text="Salvar", command=lambda: self.save_category(name_entry.get(), description_entry.get(), add_window))

        name_label.grid(row=0, column=0, padx=10, pady=10)
        name_entry.grid(row=0, column=1, padx=10, pady=10)
        description_label.grid(row=1, column=0, padx=10, pady=10)
        description_entry.grid(row=1, column=1, padx=10, pady=10)
        save_button.grid(row=2, column=0, columnspan=2, padx=10, pady=10)

    def save_category(self, name, description, window):
        # Salvar a nova categoria no banco de dados
        self.cursor.execute(f"INSERT INTO {self.table_name} (name, description) VALUES (%s, %s)", (name, description))
        self.db.commit()

        # Atualizar a Treeview
        self.load_categories()

        # Fechar a janela de adição
        window.destroy()

    def edit_category(self):
        # Obter a categoria selecionada
        selected_item = self.trv_categories.focus()
        if selected_item:
            values = self.trv_categories.item(selected_item, "values")
            category_id, name, description = values

            # Criar uma nova janela para editar a categoria
            edit_window = tk.Toplevel(self.master)
            edit_window.title("Editar Categoria")

            name_label = tk.Label(edit_window, text="Nome:")
            name_entry = tk.Entry(edit_window)
            name_entry.insert(0, name)
            description_label = tk.Label(edit_window, text="Descrição:")
            description_entry = tk.Entry(edit_window)
            description_entry.insert(0, description)
            save_button = tk.Button(edit_window, text="Salvar", command=lambda: self.update_category(category_id, name_entry.get(), description_entry.get(), edit_window))

            name_label.grid(row=0, column=0, padx=10, pady=10)
            name_entry.grid(row=0, column=1, padx=10, pady=10)
            description_label.grid(row=1, column=0, padx=10, pady=10)
            description_entry.grid(row=1, column=1, padx=10, pady=10)
            save_button.grid(row=2, column=0, columnspan=2, padx=10, pady=10)

    def update_category(self, category_id, name, description, window):
        # Atualizar a categoria no banco de dados
        self.cursor.execute(f"UPDATE {self.table_name} SET name = %s, description = %s WHERE id = %s", (name, description, category_id))
        self.db.commit()

        # Atualizar a Treeview
        self.load_categories()

        # Fechar a janela de edição
        window.destroy()

    def delete_category(self):
        # Obter a categoria selecionada
        selected_item = self.trv_categories.focus()
        if selected_item:
            values = self.trv_categories.item(selected_item, "values")
            category_id = values[0]

            # Excluir a categoria do banco de dados
            self.cursor.execute(f"DELETE FROM {self.table_name} WHERE id = %s", (category_id,))
            self.db.commit()

            # Atualizar a Treeview
            self.load_categories()