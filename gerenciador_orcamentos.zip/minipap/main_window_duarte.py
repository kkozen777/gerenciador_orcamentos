from tkinter import *
from tkinter.ttk import Combobox, Treeview
from tkinter import messagebox
import mysql.connector
import logging

# Funções auxiliares
def center(win):
    win.update_idletasks()
    width = win.winfo_width()
    frm_width = win.winfo_rootx() - win.winfo_x()
    win_width = width + 2 * frm_width
    height = win.winfo_height()
    titlebar_height = win.winfo_rooty() - win.winfo_y()
    win_height = height + titlebar_height + frm_width
    x = win.winfo_screenwidth() // 2 - win_width // 2
    y = win.winfo_screenheight() // 2 - win_height // 2
    win.geometry('{}x{}+{}+{}'.format(width, height, x, y))
    win.deiconify()

def open_categoria_window():
    categorias_window = Toplevel(home_window)
    categorias_window.geometry('725x400')
    categorias_window.title("Gestão de categorias")
    center(categorias_window)
    
    TABLE_NAME = 'categorias'
    
    # Conexão com o banco de dados MySQL
    con = mysql.connector.connect(
        host="localhost",
        user="seu_usuario",
        password="sua_senha",
        database="seu_banco"
    )
    cursor = con.cursor()
    
    def confirm_exit():
        if messagebox.askyesno('Confirmação', 'Tem certeza que deseja sair do aplicativo?'):
            categorias_window.destroy()
            logging.info('-------------------------')
            logging.info('Logs de gestão de categorias')
    
    def isPreenchido(nome_entry, tipo_entry):
        nome = nome_entry.get()
        tipo = nome_entry.get()
        if nome and tipo:
            save_categoria(nome_entry, tipo_entry, nome, tipo)
        else:
            messagebox.showwarning("Erro", "Preencha todos os campos antes de tentar salvar.")
            new_categoria_window()
    
    def iSelected(tree, funcao):
        selecionada = tree.selection()
        if funcao == 1:
            if selecionada:
                delete_categoria(selecionada)
            else:
                messagebox.showwarning("Erro", "Selecione uma categoria antes de tentar eliminar.")
        elif funcao == 2:
            if selecionada:
                update_categoria(selecionada)
            else:
                messagebox.showwarning("Erro", "Selecione uma categoria antes de tentar atualizar.")
    
    def eliminarDadosTreeView():
        for item in trv_lista_categorias.get_children():
            trv_lista_categorias.delete(item)
    
    def combobox(event):
        if filtros_combobox.get() == "Ordenar por código":
            eliminarDadosTreeView()
            cursor.execute(f"SELECT id, nome, tipo FROM {TABLE_NAME}")
            categorias = cursor.fetchall()
            for id, nome, tipo in categorias:
                trv_lista_categorias.insert("", END, values=(id, nome, tipo))
    
    # Criação dos controles
    title_label = Label(categorias_window, text="Gestão de categorias", font=("Consolas", 15))
    title_label.grid(row=0, column=0, columnspan=3, padx=10, pady=0, sticky="W")
    
    filtros_combobox = Combobox(categorias_window, text="Lista de Categorias", font=("Consolas", 10))
    filtros_combobox.grid(row=0, column=4, padx=10, pady=10, sticky="E")
    filtros_combobox['state'] = 'readonly'
    filtros_combobox['values'] = ('Ordenar por código')
    filtros_combobox.set('Ordenar por')
    filtros_combobox.bind('<<ComboboxSelected>>', combobox)
    
    # Criar a Treeview
    trv_lista_categorias = Treeview(categorias_window, columns=("id", "nome", "tipo"), show='headings')
    
    # Nome das colunas do Treeview
    trv_lista_categorias.heading("id", text="ID")
    trv_lista_categorias.heading("nome", text="Nome")
    trv_lista_categorias.heading("tipo", text="Tipo")
    
    # Tamanho de cada coluna
    trv_lista_categorias.column("id", width=75)
    trv_lista_categorias.column("nome", width=150)
    trv_lista_categorias.column("tipo", width=100)
    
    # Inserção dos dados das categorias no Treeview
    cursor.execute(f"SELECT id, nome, tipo FROM {TABLE_NAME}")
    categorias = cursor.fetchall()
    for id, nome, tipo in categorias:
        trv_lista_categorias.insert("", END, values=(id, nome, tipo))
    
    trv_lista_categorias.grid(row=2, column=0, columnspan=5, padx=10, pady=10, sticky="NSEW")
    
    # Adicionar botões
    btn_save_categoria = Button(categorias_window, text="Inserir nova categoria", font=("Consolas", 11), command=new_categoria_window)
    btn_delete_categoria = Button(categorias_window, text="Eliminar categoria", font=("Consolas", 11), command=lambda: iSelected(trv_lista_categorias, 1))
    btn_update_categoria = Button(categorias_window, text="Atualizar categoria", font=("Consolas", 11), command=lambda: iSelected(trv_lista_categorias, 2))
    btn_exit = Button(categorias_window, text="Fechar Aplicação", font=("Consolas", 11), command=confirm_exit)
    
    btn_save_categoria.grid(row=3, column=1, padx=10, pady=10, sticky="W")
    btn_delete_categoria.grid(row=3, column=2, padx=10, pady=10, sticky="W")
    btn_update_categoria.grid(row=3, column=3, padx=10, pady=10, sticky="E")
    btn_exit.grid(row=3, column=4, padx=10, pady=10, sticky="E")
    
    categorias_window.grid_columnconfigure(0, weight=1)
    categorias_window.grid_columnconfigure(1, weight=1)
    categorias_window.grid_columnconfigure(2, weight=1)
    categorias_window.grid_columnconfigure(3, weight=1)
    categorias_window.grid_rowconfigure(1, weight=1)
    
    class Categoria:
        def __init__(self, nome, tipo):
            self.nome = nome
            self.tipo = tipo
    
    def clear_boxes(box1, *boxes):
        box1.delete(0, 'end')
        for box in boxes:
            box.delete(0, 'end')
        box1.focus_set()
    
    def default_boxes(nome, tipo):
        clear_boxes(nome, tipo)
        nome.insert(0, "")
        tipo.insert(0, "")
    
    def save_categoria(nome_entry, tipo_entry, nome, tipo):
        cursor.execute(f'INSERT INTO {TABLE_NAME} (id_utilizador, nome, tipo) VALUES (%s, %s, %s)', (1, nome, tipo))
        con.commit()
        last_id = cursor.lastrowid
        trv_lista_categorias.insert("", END, values=(last_id, nome, tipo))
        clear_boxes(nome_entry, tipo_entry)
    
    def delete_categoria(index):
        item_values = trv_lista_categorias.item(index, "values")
        db_id = item_values[0]
        sql = f'DELETE FROM {TABLE_NAME} WHERE id = {db_id}'
        trv_lista_categorias.delete(index)
        cursor.execute(sql)
        con.commit()
    
    def update_categoria(index):
        item_values = trv_lista_categorias.item(index, "values")
        db_id = item_values[0]
        window = atualizar_categoria_form(db_id, index)
        center(window)
        window.mainloop()
    
    def auxiliar_update_categoria(db_id, index, nome_entry, tipo_entry):
        nome = nome_entry.get()
        tipo = tipo_entry.get()
        cursor.execute(f'UPDATE {TABLE_NAME} SET nome = %s, tipo = %s WHERE id = %s', (nome, tipo, db_id))
        con.commit()
        trv_lista_categorias.item(index, values=(db_id, nome, tipo))
    
    class novo_categoria_form(Toplevel):
        def __init__(self):
            super().__init__()
            self.geometry('400x200')
            self.title('Nova categoria')
            
            # Create controls
            my_nome_label = Label(self, text="Nome", justify="left")
            my_nome_text = Entry(self, width=62)
            my_tipo_label = Label(self, text="Tipo", justify="left")
            my_tipo_text = Entry(self, width=62)
            btn_insert = Button(self, text="Inserir nova categoria", width=21, padx=10, pady=5, command=lambda: isPreenchido(my_nome_text, my_tipo_text))
            btn_cancel = Button(self, text="Limpar campos", width=21, padx=10, pady=5, command=lambda: clear_boxes(my_nome_text, my_tipo_text))
            
            # Insert controls into the form
            my_nome_label.grid(row=0, column=0, padx=(10, 0), sticky="W")
            my_nome_text.grid(row=1, column=0, columnspan=2, padx=(10, 0), pady=(0, 10))
            my_tipo_label.grid(row=2, column=0, padx=(10, 0), sticky="W")
            my_tipo_text.grid(row=3, column=0, columnspan=2, padx=(10, 0), pady=(0, 10))
            btn_insert.grid(row=4, column=0, padx=(10, 0))
            btn_cancel.grid(row=4, column=1, padx=(10, 0))
    
    class atualizar_categoria_form(Toplevel):
        def __init__(self, db_id, index):
            super().__init__()
            self.geometry('400x200')
            self.title('Atualizar categoria')
            # Create controls
            my_nome_label = Label(self, text="Nome", justify="left")
            cursor.execute(f"SELECT nome FROM {TABLE_NAME} WHERE id = {db_id}")
            nome_categoria = cursor.fetchone()[0]
            my_nome_text = Entry(self, width=62)
            my_nome_text.insert(0, nome_categoria)
            
            my_tipo_label = Label(self, text="Tipo", justify="left")
            cursor.execute(f"SELECT tipo FROM {TABLE_NAME} WHERE id = {db_id}")
            tipo_categoria = cursor.fetchone()[0]
            my_tipo_text = Entry(self, width=62)
            my_tipo_text.insert(0, tipo_categoria)
            
            btn_update = Button(self, text="Atualizar categoria", width=21, padx=10, pady=5, command=lambda: auxiliar_update_categoria(db_id, index, my_nome_text, my_tipo_text))
            btn_cancel = Button(self, text="Limpar campos", width=21, padx=10, pady=5, command=lambda: default_boxes(my_nome_text, my_tipo_text))
            
            # Insert controls into the form
            my_nome_label.grid(row=0, column=0, padx=(10, 0), sticky="W")
            my_nome_text.grid(row=1, column=0, columnspan=2, padx=(10, 0), pady=(0, 10))
            my_tipo_label.grid(row=2, column=0, padx=(10, 0), sticky="W")
            my_tipo_text.grid(row=3, column=0, columnspan=2, padx=(10, 0), pady=(0, 10))
            btn_update.grid(row=4, column=0, padx=(10, 0))
            btn_cancel.grid(row=4, column=1, padx=(10, 0))
    
    categorias_window.protocol("WM_DELETE_WINDOW", confirm_exit)

# Janela principal
home_window = Tk()
home_window.geometry('300x200')
home_window.title("Home")

# Botão para abrir a janela de categorias
btn_open_categoria = Button(home_window, text="Categorias", font=("Consolas", 12), command=open_categoria_window)
btn_open_categoria.pack(pady=20)

home_window.mainloop()
