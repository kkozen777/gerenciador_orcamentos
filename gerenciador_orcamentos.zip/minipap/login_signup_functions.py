from tkinter import *
from tkinter import messagebox  # Importa módulo de messagebox do tkinter
import connection as conect  # Importa módulo de conexão personalizado
from home_window import *  # Importa a classe HomeWindow do módulo home_window
from general_functions import *  # Importa funções gerais

# Classe para representar um usuário
class User:
    def __init__(self, username, email, password):
        self.username = username  # Nome de usuário
        self.email = email  # Email do usuário
        self.password = password  # Senha do usuário

# Função para salvar um novo usuário no banco de dados
def save_user(username_entry, email_entry, password_entry):
    username = username_entry.get()  # Obtém o valor do campo de entrada de username
    email = email_entry.get()  # Obtém o valor do campo de entrada de email
    password = password_entry.get()  # Obtém o valor do campo de entrada de senha
    
    # Verifica se todos os campos foram preenchidos
    if not (username and email and password):
        messagebox.showerror("Erro", "Todos os campos são obrigatórios")  # Exibe mensagem de erro se algum campo estiver vazio
        return
    
    new_user = User(username, email, password)  # Cria um objeto User com os dados inseridos
    connection = conect.connect_to_database()  # Conecta ao banco de dados
    
    if connection:
        cursor = connection.cursor()  # Cria um cursor para executar comandos SQL
        try:
            # Executa o comando SQL para inserir um novo usuário no banco de dados
            cursor.execute("INSERT INTO utilizador (nome, email, senha) VALUES (%s, %s, %s)", (new_user.username, new_user.email, new_user.password))
            connection.commit()  # Confirma a transação no banco de dados
            messagebox.showinfo("Sucesso", "Usuário inserido com sucesso!")  # Exibe mensagem de sucesso
            clear_boxes(username_entry, email_entry, password_entry)  # Limpa os campos de entrada
        except conect.mysql.connector.Error as err:
            messagebox.showerror("Erro", f"Erro ao inserir usuário: {err}")  # Exibe mensagem de erro se houver problema na inserção
        finally:
            cursor.close()  # Fecha o cursor
            connection.close()  # Fecha a conexão com o banco de dados

# Função para limpar os campos de entrada
def clear_boxes(*entries):
    for entry in entries:
        entry.delete(0, END)  # Deleta o conteúdo atual dos campos de entrada

# Função para realizar o login do usuário
def login_user(email_entry, password_entry):
    email = email_entry.get()  # Obtém o valor do campo de entrada de email
    password = password_entry.get()  # Obtém o valor do campo de entrada de senha
    
    # Verifica se todos os campos foram preenchidos
    if not (email and password):
        messagebox.showerror("Erro", "Todos os campos são obrigatórios")  # Exibe mensagem de erro se algum campo estiver vazio
        return
    
    connection = conect.connect_to_database()  # Conecta ao banco de dados
    
    if connection:
        cursor = connection.cursor()  # Cria um cursor para executar comandos SQL
        try:
            # Executa o comando SQL para selecionar o usuário com o email fornecido
            cursor.execute("SELECT id, email, nome, senha FROM utilizador WHERE email = %s", (email,))
            result = cursor.fetchone()  # Obtém o primeiro resultado da consulta
            if result[3] == password:  # Verifica se a senha corresponde à senha do usuário encontrado
                messagebox.showinfo("Sucesso", f"Bem-vindo, {result[2]}!")  # Exibe mensagem de sucesso com o nome do usuário
                clear_boxes(email_entry, password_entry)  # Limpa os campos de entrada
                open_home_window(result[0], result[1], result[2], result[3])  # Abre a janela principal após o login bem-sucedido
            else:
                messagebox.showerror("Erro", "Email ou senha incorretos")  # Exibe mensagem de erro se a senha estiver incorreta
        except conect.mysql.connector.Error as err:
            messagebox.showerror("Erro", f"Erro ao realizar login: {err}")  # Exibe mensagem de erro se houver problema na consulta
        finally:
            cursor.close()  # Fecha o cursor
            connection.close()  # Fecha a conexão com o banco de dados

# Função para centralizar uma janela na tela
def center(win):
    win.update_idletasks()  # Atualiza a interface da janela
    width = win.winfo_width()  # Obtém a largura da janela
    frm_width = win.winfo_rootx() - win.winfo_x()  # Calcula a largura da moldura da janela
    win_width = width + 2 * frm_width  # Calcula a largura total da janela
    height = win.winfo_height()  # Obtém a altura da janela
    titlebar_height = win.winfo_rooty() - win.winfo_y()  # Calcula a altura da barra de título da janela
    win_height = height + titlebar_height + frm_width  # Calcula a altura total da janela
    x = win.winfo_screenwidth() // 2 - win_width // 2  # Calcula a posição X para centralizar a janela na tela
    y = win.winfo_screenheight() // 2 - win_height // 2  # Calcula a posição Y para centralizar a janela na tela
    win.geometry('{}x{}+{}+{}'.format(width, height, x, y))  # Define a geometria da janela para centralizá-la na tela
    win.deiconify()  # Exibe a janela

# Classe para criar a janela de cadastro de novo usuário
class SignupForm(Toplevel):
    def __init__(self):
        super().__init__()  # Inicializa a janela
        self.geometry('480x300')  # Define as dimensões da janela
        self.title('New User')  # Define o título da janela
        
        # Cria os widgets da interface
        username_label = Label(self, text="Username")  # Label para nome de usuário
        self.username_entry = Entry(self, width=62)  # Campo de entrada para nome de usuário
        email_label = Label(self, text="Email")  # Label para email
        self.email_entry = Entry(self, width=62)  # Campo de entrada para email
        password_label = Label(self, text="Password")  # Label para senha
        self.password_entry = Entry(self, show="*", width=62)  # Campo de entrada para senha
        
        # Botões para inserir novo usuário e cancelar
        btn_insert = Button(self, text="Insert New User", width=21, pady=5, command=lambda: save_user(self.username_entry, self.email_entry, self.password_entry))
        btn_cancel = Button(self, text="Cancel", width=21, pady=5, command=lambda: clear_boxes(self.username_entry, self.email_entry, self.password_entry))
        
        # Posicionamento dos widgets na grade da janela
        username_label.grid(row=0, column=0, padx=(10,0), sticky="W")
        self.username_entry.grid(row=1, column=0, columnspan=2, padx=(10,0), pady=(0,10))
        
        email_label.grid(row=3, column=0, padx=(10,0), sticky="W")
        self.email_entry.grid(row=4, column=0, columnspan=2, padx=(10,0), pady=(0,10))
        
        password_label.grid(row=6, column=0, padx=(10,0), sticky="W")
        self.password_entry.grid(row=7, column=0, columnspan=2, padx=(10,0), pady=(0,10))
        
        btn_insert.grid(row=9, column=0, padx=(10,0))
        btn_cancel.grid(row=9, column=1, padx=(10,0))

# Classe para criar a janela de login
class LoginForm(Toplevel):
    def __init__(self):
        super().__init__()  # Inicializa a janela
        self.geometry('480x300')  # Define as dimensões da janela
        self.title('Login')  # Define o título da janela
        
        # Cria os widgets da interface
        email_label = Label(self, text="Email")  # Label para email
        self.email_entry = Entry(self, width=62)  # Campo de entrada para email
        password_label = Label(self, text="Password")  # Label para senha
        self.password_entry = Entry(self, show="*", width=62)  # Campo de entrada para senha
        
        # Botões para realizar login e cancelar
        btn_insert = Button(self, text="login", width=21, pady=5, command=lambda: login_user(self.email_entry, self.password_entry))
        btn_cancel = Button(self, text="Cancel", width=21, pady=5, command=lambda: clear_boxes(self.email_entry, self.password_entry))
                
        # Posicionamento dos widgets na grade da janela
        email_label.grid(row=3, column=0, padx=(10,0), sticky="W")
        self.email_entry.grid(row=4, column=0, columnspan=2, padx=(10,0), pady=(0,10))
        
        password_label.grid(row=6, column=0, padx=(10,0), sticky="W")
        self.password_entry.grid(row=7, column=0, columnspan=2, padx=(10,0), pady=(0,10))
        
        btn_insert.grid(row=9, column=0, padx=(10,0))
        btn_cancel.grid(row=9, column=1, padx=(10,0))

# Função para abrir a janela de cadastro de novo usuário
def signup_window():
    window = SignupForm()  # Cria a janela de cadastro
    center(window)  # Centraliza a janela na tela
    window.mainloop()  # Inicia o loop principal da janela

# Função para abrir a janela de login
def login_window():
    window = LoginForm()  # Cria a janela de login
    center(window)  # Centraliza a janela na tela
    window.mainloop()  # Inicia o loop principal da janela