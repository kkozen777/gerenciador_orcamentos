import tkinter as tk
from tkinter import messagebox
import mysql.connector

def connect_to_database():
    try:
        connection = mysql.connector.connect(
            host="localhost",
            user="root",
            password='root',
            database="orcamentosfamiliares"
        )
        if connection.is_connected():
            print("Conexão bem-sucedida!")
        return connection
    except mysql.connector.Error as err:
        messagebox.showerror("Erro", f"Erro ao conectar: {err}")
        return None

