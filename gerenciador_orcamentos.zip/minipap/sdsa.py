from tkinter import *
from tkinter import simpledialog, messagebox
import connection as conect

class SelectedAccount:
    def __init__(self):
        self.id = None
        self.nome = None
        self.saldo = None
        self.idade = None

    def update(self, account_id, account_nome, account_saldo, account_idade):
        self.id = account_id
        self.nome = account_nome
        self.saldo = account_saldo
        self.idade = account_idade

    def clear(self):
        self.id = None
        self.nome = None
        self.saldo = None
        self.idade = None

class LoggedUser:
    def __init__(self, user_id, username, email, password):
        self.id = user_id
        self.username = username
        self.email = email
        self.password = password

class HomeWindow(Toplevel):
    def __init__(self, user):
        super().__init__()
        self.user_id = user.id
        self.username = user.username
        self.password = user.password
        self.nome = user.password
        self.email = user.email
        
        self.logged_user = user
        self.selected_account = SelectedAccount()

        self.title("Home Page")
        self.geometry("600x400")

        self.menu = Menu(self)
        self.config(menu=self.menu)

        self.account_menu = Menu(self.menu, tearoff=0)
        self.menu.add_cascade(label="Contas", menu=self.account_menu)

        self.account_menu.add_command(label="Criar Nova Conta", command=self.create_account)
        self.load_accounts()

        self.welcome_label = Label(self, text="Nenhuma conta foi selecionada", font=("Arial", 16))
        self.welcome_label.pack(pady=20)

        self.account_info_frame = Frame(self)
        self.account_info_frame.pack(pady=20)

        self.buttons_frame = Frame(self)
        self.buttons_frame.pack(pady=10)
        
    def load_accounts(self):
        connection = conect.connect_to_database()
        if connection:
            cursor = connection.cursor()
            try:
                cursor.execute("SELECT id, nome, saldo, idade FROM account WHERE utilizador_id = %s", (self.user_id,))
                accounts = cursor.fetchall()
                if accounts:
                    for account in accounts:
                        self.account_menu.add_command(label=account[1], command=lambda acc=account: self.select_account(acc))
                else:
                    self.account_menu.add_command(label="Nenhuma conta disponível", state=DISABLED)
            except conect.mysql.connector.Error as err:
                messagebox.showerror("Erro", f"Erro ao carregar contas: {err}")
            finally:
                cursor.close()
                connection.close()

    def create_account(self):
        account_name = simpledialog.askstring("Nome da Conta", "Digite o nome da nova conta:")
        account_saldo = simpledialog.askstring("Saldo da Conta", "Digite o Saldo da nova conta:")
        account_idade = simpledialog.askstring("Idade do dono", "Digite a idade do dono da nova conta:")

        if account_name:
            connection = conect.connect_to_database()
            if connection:
                cursor = connection.cursor()
                try:
                    cursor.execute("INSERT INTO account (utilizador_id, nome, saldo, idade) VALUES (%s, %s, %s, %s)",
                                   (self.user_id, account_name, account_saldo, account_idade))
                    connection.commit()
                    messagebox.showinfo("Sucesso", "Conta criada com sucesso!")
                    self.load_accounts()
                except conect.mysql.connector.Error as err:
                    messagebox.showerror("Erro", f"Erro ao criar conta: {err}")
                finally:
                    cursor.close()
                    connection.close()

    def select_account(self, account):
        account_id, account_nome, account_saldo, account_idade = account
        self.selected_account.update(account_id, account_nome, account_saldo, account_idade)
        self.update_welcome_label()
        self.show_account_buttons()

    def update_welcome_label(self):
        if self.selected_account.nome:
            self.welcome_label.config(text=f"Conta selecionada: {self.selected_account.nome}")
        else:
            self.welcome_label.config(text="Nenhuma conta foi selecionada")
    
    def show_account_buttons(self):
        for widget in self.buttons_frame.winfo_children():
            widget.destroy()

        btn_deposit = Button(self.buttons_frame, text="Depositar", command=self.deposit)
        btn_withdraw = Button(self.buttons_frame, text="Sacar", command=self.withdraw)
        btn_transfer = Button(self.buttons_frame, text="Transferir", command=self.transfer)

        btn_deposit.pack(side=LEFT, padx=10)
        btn_withdraw.pack(side=LEFT, padx=10)
        btn_transfer.pack(side=LEFT, padx=10)

    def deposit(self):
        amount = simpledialog.askfloat("Depositar", "Digite o valor para depositar:")
        if amount is not None:
            # Lógica para depósito aqui
            messagebox.showinfo("Depositar", f"Depósito de {amount} na conta {self.selected_account.nome} efetuado com sucesso.")

    def withdraw(self):
        amount = simpledialog.askfloat("Sacar", "Digite o valor para sacar:")
        if amount is not None:
            # Lógica para saque aqui
            messagebox.showinfo("Sacar", f"Saque de {amount} da conta {self.selected_account.nome} efetuado com sucesso.")

    def transfer(self):
        amount = simpledialog.askfloat("Transferir", "Digite o valor para transferir:")
        if amount is not None:
            # Lógica para transferência aqui
            messagebox.showinfo("Transferir", f"Transferência de {amount} da conta {self.selected_account.nome} efetuada com sucesso.")

def open_home_window(user_id, username, email, password):
    logged_user = LoggedUser(user_id, username, email, password)
    HomeWindow(logged_user).mainloop()