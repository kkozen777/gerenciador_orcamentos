import tkinter as tk

# Criar a janela principal
root = tk.Tk()
root.title("Janela com 10 Botões")

# Criar os 10 botões
btn1 = tk.Button(root, text="Botão 1")
btn2 = tk.Button(root, text="Botão 2")
btn3 = tk.Button(root, text="Botão 3")
btn4 = tk.Button(root, text="Botão 4")
btn5 = tk.Button(root, text="Botão 5")
btn6 = tk.Button(root, text="Botão 6")
btn7 = tk.Button(root, text="Botão 7")
btn8 = tk.Button(root, text="Botão 8")
btn9 = tk.Button(root, text="Botão 9")
btn10 = tk.Button(root, text="Botão 10")

# Posicionar os botões na janela
btn1.grid(row=0, column=0, padx=10, pady=10)
btn2.grid(row=0, column=1, padx=10, pady=10)
btn3.grid(row=0, column=2, padx=10, pady=10)
btn4.grid(row=0, column=3, padx=10, pady=10)
btn5.grid(row=0, column=4, padx=10, pady=10)
btn6.grid(row=1, column=0, padx=10, pady=10)
btn7.grid(row=1, column=1, padx=10, pady=10)
btn8.grid(row=1, column=2, padx=10, pady=10)
btn9.grid(row=1, column=3, padx=10, pady=10)
btn10.grid(row=1, column=4, padx=10, pady=10)

# Iniciar o loop da janela
root.mainloop()