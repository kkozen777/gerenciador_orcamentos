from tkinter import messagebox

def clear_boxes(box1,*boxes):
    box1.delete(0,'end')
    for box in boxes:
        box.delete(0,'end')
    box1.focus_set()

def exit_app(win):
    answer = messagebox.askquestion('Exit aplication','Are you sure ?')
    if answer == 'yes':
        exit()