from tkinter import *
from tkinter.ttk import Combobox, Treeview
from tkinter import messagebox
import mysql.connector
import logging
def new_categoria_window():
    window = novo_categoria_form()
    center(window)
    window.mainloop()
    
con = mysql.connector.connect(
    host="localhost",
    user="root",
    password="root",
    database="orcamentosfamiliares"
)
cursor = con.cursor()

TABLE_NAME = 'categorias'

# Funções auxiliares
def center(win):
    win.update_idletasks()
    width = win.winfo_width()
    frm_width = win.winfo_rootx() - win.winfo_x()
    win_width = width + 2 * frm_width
    height = win.winfo_height()
    titlebar_height = win.winfo_rooty() - win.winfo_y()
    win_height = height + titlebar_height + frm_width
    x = win.winfo_screenwidth() // 2 - win_width // 2
    y = win.winfo_screenheight() // 2 - win_height // 2
    win.geometry('{}x{}+{}+{}'.format(width, height, x, y))
    win.deiconify()
# Janela principal
window = Tk()
window.geometry('725x400')
window.title("Gestão de categorias")
center(window)









# Criação dos controles
title_label = Label(window, text="Gestão de categorias", font=("Consolas", 15))
title_label.grid(row=0, column=0, columnspan=3, padx=10, pady=0, sticky="W")

filtros_combobox = Combobox(window, text="Lista de Categorias", font=("Consolas", 10))
filtros_combobox.grid(row=0, column=4, padx=10, pady=10, sticky="E")

# Criar a Treeview
trv_lista_categorias = Treeview(window, columns=("id", "nome", "tipo"), show='headings')

# Nome das colunas do Treeview
trv_lista_categorias.heading("id", text="ID")
trv_lista_categorias.heading("nome", text="Nome")
trv_lista_categorias.heading("tipo", text="Tipo")

# Tamanho de cada coluna
trv_lista_categorias.column("id", width=75)
trv_lista_categorias.column("nome", width=150)
trv_lista_categorias.column("tipo", width=100)

# Inserção dos dados das categorias no Treeview
cursor.execute(f"SELECT id, nome, tipo FROM {TABLE_NAME}")
categorias = cursor.fetchall()
for id, nome, tipo in categorias:
    trv_lista_categorias.insert("", END, values=(id, nome, tipo))

trv_lista_categorias.grid(row=2, column=0, columnspan=5, padx=10, pady=10, sticky="NSEW")

# Adicionar botões
btn_save_categoria = Button(window, text="Inserir nova categoria", font=("Consolas", 11), command=new_categoria_window)
btn_delete_categoria = Button(window, text="Eliminar categoria", font=("Consolas", 11), command=lambda:...)
btn_update_categoria = Button(window, text="Atualizar categoria", font=("Consolas", 11), command=lambda:...)
btn_exit = Button(window, text="Fechar Aplicação", font=("Consolas", 11), command=...)

btn_save_categoria.grid(row=3, column=1, padx=10, pady=10, sticky="W")
btn_delete_categoria.grid(row=3, column=2, padx=10, pady=10, sticky="W")
btn_update_categoria.grid(row=3, column=3, padx=10, pady=10, sticky="E")
btn_exit.grid(row=3, column=4, padx=10, pady=10, sticky="E")

window.grid_columnconfigure(0, weight=1)
window.grid_columnconfigure(1, weight=1)
window.grid_columnconfigure(2, weight=1)
window.grid_columnconfigure(3, weight=1)
window.grid_rowconfigure(1, weight=1)

class novo_categoria_form(Toplevel):
    def __init__(self):
        super().__init__()
        self.geometry('400x200')
        self.title('Nova categoria')
        
        # Create controls
        my_nome_label = Label(self, text="Nome", justify="left")
        my_nome_text = Entry(self, width=62)
        my_tipo_label = Label(self, text="Tipo", justify="left")
        my_tipo_text = Entry(self, width=62)
        btn_insert = Button(self, text="Inserir nova categoria", width=21, padx=10, pady=5, command=lambda:...)
        btn_cancel = Button(self, text="Limpar campos", width=21, padx=10, pady=5, command=lambda: ...)
        
        # Insert controls into the form
        my_nome_label.grid(row=0, column=0, padx=(10, 0), sticky="W")
        my_nome_text.grid(row=1, column=0, columnspan=2, padx=(10, 0), pady=(0, 10))
        my_tipo_label.grid(row=2, column=0, padx=(10, 0), sticky="W")
        my_tipo_text.grid(row=3, column=0, columnspan=2, padx=(10, 0), pady=(0, 10))

        btn_insert.grid(row=4, column=0, padx=(10, 0))
        btn_cancel.grid(row=4, column=1, padx=(10, 0))

class atualizar_categoria_form(Toplevel):
    def __init__(self, db_id, index):
        super().__init__()
        self.geometry('400x200')
        self.title('Atualizar categoria')

        # Create controls
        my_nome_label = Label(self, text="Nome", justify="left")

        nome_categoria = cursor.fetchone()[0]
        my_nome_text = Entry(self, width=62)
        my_nome_text.insert(0, nome_categoria)
        
        my_tipo_label = Label(self, text="Tipo", justify="left")
        tipo_categoria = cursor.fetchone()[0]
        my_tipo_text = Entry(self, width=62)
        my_tipo_text.insert(0, tipo_categoria)
        
        btn_update = Button(self, text="Atualizar categoria", width=21, padx=10, pady=5, command=lambda: ...)
        btn_cancel = Button(self, text="Limpar campos", width=21, padx=10, pady=5, command=lambda: ...)
        
        # Insert controls into the form
        my_nome_label.grid(row=0, column=0, padx=(10, 0), sticky="W")
        my_nome_text.grid(row=1, column=0, columnspan=2, padx=(10, 0), pady=(0, 10))
        my_tipo_label.grid(row=2, column=0, padx=(10, 0), sticky="W")
        my_tipo_text.grid(row=3, column=0, columnspan=2, padx=(10, 0), pady=(0, 10))

        btn_update.grid(row=4, column=0, padx=(10, 0))
        btn_cancel.grid(row=4, column=1, padx=(10, 0))




window.protocol("WM_DELETE_WINDOW")


window.mainloop()
