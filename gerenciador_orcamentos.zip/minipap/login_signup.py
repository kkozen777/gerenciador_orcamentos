from tkinter import *
from login_signup_functions import *
from general_functions import *

window = Tk()
window.geometry('600x480')
window.title("Login Signup")
center(window)

btn_new_usr = Button(window, text= "Signup", width=35,pady=25, font=("Consolas",16),command=lambda: SignupForm())
btn_new_usr.pack(expand= True)

btn_users_list = Button(window, text= "Login", width=35,pady=25, font=("Consolas",16), command=lambda: LoginForm())
btn_users_list.pack(expand=True)

btn_exit = Button(window, text= "Exit Aplication", width=35,pady=25, font=("Consolas",16), command=lambda:exit_app('window'))
btn_exit.pack(expand=True)

window.mainloop()