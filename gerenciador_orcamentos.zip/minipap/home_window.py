from tkinter import *
from tkinter import simpledialog, messagebox  # Importa ficheiros necessários do tkinter
import connection as conect  # Importa ficheiro de conexão com a base de dados
from general_functions import clear_boxes  # Importa outras funções gerais
from main_window_duarte import new_categoria_window

# Classe para guardar os dados da conta selecionada
class SelectedAccount:
    def __init__(self):
        # None caso não haja nenhuma selecionada
        self.id = None  # ID da conta
        self.nome = None  # Nome da conta
        self.saldo = None  # Saldo da conta
        self.idade = None  # Idade do dono da conta

    # Método para atualizar os dados da conta selecionada, ou seja, ao selecionar uma conta muda os dados
    def update(self, account_id, account_nome, account_saldo, account_idade):
        self.id = account_id
        self.nome = account_nome
        self.saldo = account_saldo
        self.idade = account_idade

    # Método para limpar os dados da conta selecionada
    def clear(self):
        self.id = None
        self.nome = None
        self.saldo = None
        self.idade = None

# Classe para representar o user que entrou
class LoggedUser:
    def __init__(self, user_id, username, email, password):
        self.id = user_id  # ID do user
        self.username = username  # Nome douser
        self.email = email  # Email do user
        self.password = password  # Senha do user

# Classe da janela principal da aplicação
class HomeWindow(Toplevel):
    def __init__(self, user):
        super().__init__()  # Inicializa a janela principal
        self.user_id = user.id  # ID do user que entrou
        self.username = user.username  # Nome do user
        self.password = user.password  # Senha do user
        self.email = user.email  # Email do user

        self.logged_user = user  # Guarda o objeto criado do user que entrou
        self.selected_account = SelectedAccount()  # Guarda conta selecionada

        self.title("Home Page")  # Título da janela
        self.geometry("600x300")  # Tamanho da janela

        self.menu = Menu(self)  # Cria menu
        self.config(menu=self.menu)  # Configura o menu na janela

        self.account_menu = Menu(self.menu, tearoff=0)  # Menu das contas 
        self.menu.add_cascade(label="Contas", menu=self.account_menu)  # Adiciona o menu de contas ao menu principal

        self.account_menu.add_command(label="Criar Nova Conta", command=self.create_account)  # Adiciona opção de criar nova conta
        self.load_accounts()  # Carrega as contas do user

        self.welcome_label = Label(self, text="Nenhuma conta foi selecionada", font=("Arial", 16))
        self.welcome_label.pack(pady=20)

        self.account_info_frame = Frame(self)
        self.account_info_frame.pack(pady=20)

        self.buttons_frame = Frame(self)
        self.buttons_frame.pack(pady=10)

    # Método para carregar as contas do user
    def load_accounts(self):
        connection = conect.connect_to_database()  # Conecta ao banco de dados
        if connection:
            cursor = connection.cursor()  # Cria cursor para executar comandos SQL
            try:
                cursor.execute("SELECT id, nome, saldo, idade FROM account WHERE utilizador_id = %s", (self.user_id,))
                accounts = cursor.fetchall()  # Obtém todas as contas do user
                if accounts:
                    for account in accounts:
                        # Adiciona uma opção no menu de contas para cada conta encontrada
                        self.account_menu.add_command(label=account[1], command=lambda acc=account: self.select_account(acc))
                else:
                    self.account_menu.add_command(label="Nenhuma conta disponível", state=DISABLED)  # Nenhuma conta disponível
            except conect.mysql.connector.Error as err:
                messagebox.showerror("Erro", f"Erro ao carregar contas: {err}")  # Exibe erro se houver problema ao carregar contas
            finally:
                cursor.close()  # Fecha o cursor
                connection.close()  # Fecha a conexão com o banco de dados

    # Método para criar uma nova conta
    def create_account(self):
        account_name = simpledialog.askstring("Nome da Conta", "Digite o nome da nova conta:")  # Solicita nome da nova conta
        account_saldo = simpledialog.askfloat("Saldo da Conta", "Digite o saldo da nova conta:")  # Solicita saldo da nova conta
        account_idade = simpledialog.askinteger("Idade do dono", "Digite a idade do dono da nova conta:")  # Solicita idade do dono da nova conta

        if account_name and account_saldo is not None and account_idade is not None:
            connection = conect.connect_to_database()  # Conecta ao banco de dados
            if connection:
                cursor = connection.cursor()  # Cria cursor para executar comandos SQL
                try:
                    # Insere os dados da nova conta no banco de dados
                    cursor.execute("INSERT INTO account (utilizador_id, nome, saldo, idade) VALUES (%s, %s, %s, %s)",
                                   (self.user_id, account_name, account_saldo, account_idade))
                    connection.commit()  # Confirma a transação no banco de dados
                    messagebox.showinfo("Sucesso", "Conta criada com sucesso!")  # Exibe mensagem de sucesso
                    self.load_accounts()  # Recarrega a lista de contas na interface
                except conect.mysql.connector.Error as err:
                    messagebox.showerror("Erro", f"Erro ao criar conta: {err}")  # Exibe erro se houver problema ao criar conta
                finally:
                    cursor.close()  # Fecha o cursor
                    connection.close()  # Fecha a conexão com o banco de dados

    # Método para selecionar uma conta
    def select_account(self, account):
        account_id, account_nome, account_saldo, account_idade = account
        self.selected_account.update(account_id, account_nome, account_saldo, account_idade)
        self.update_welcome_label()
        self.show_account_buttons()

    def update_welcome_label(self):
        if self.selected_account.nome:
            self.welcome_label.config(text=f"Conta selecionada: {self.selected_account.nome}")
        else:
            self.welcome_label.config(text="Nenhuma conta foi selecionada")
    
    def show_account_buttons(self):
        for widget in self.buttons_frame.winfo_children():
            widget.destroy()

        btn_categorias = Button(self.buttons_frame, text="Criar categoria", command=self.categorias)
        btn_withdraw = Button(self.buttons_frame, text="Sacar", command=self.withdraw)
        btn_transfer = Button(self.buttons_frame, text="Transferir", command=self.transfer)

        btn_categorias.pack(side=LEFT, padx=10)
        btn_withdraw.pack(side=LEFT, padx=10)
        btn_transfer.pack(side=LEFT, padx=10)
        
    def categorias(self):
        ...

    def withdraw(self):
        amount = simpledialog.askfloat("Sacar", "Digite o valor para sacar:")
        if amount is not None:
            # Lógica para saque aqui
            messagebox.showinfo("Sacar", f"Saque de {amount} da conta {self.selected_account.nome} efetuado com sucesso.")

    def transfer(self):
        amount = simpledialog.askfloat("Transferir", "Digite o valor para transferir:")
        if amount is not None:
            # Lógica para transferência aqui
            messagebox.showinfo("Transferir", f"Transferência de {amount} da conta {self.selected_account.nome} efetuada com sucesso.")

# Função para abrir a janela principal
def open_home_window(user_id, username, email, password):
    logged_user = LoggedUser(user_id, username, email, password) 
    HomeWindow(logged_user).mainloop()  # Cria e inicia a janela principal da aplicação

#
